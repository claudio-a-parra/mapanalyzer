// compile  : gcc -Wall -g -O0 -save-temps -fno-inline
// run-args :
// prefix   : valgrind --verbose --read-var-info=yes --tool=cachegrind

#define BLK 1024
//#include <stdlib.h>
int monfun(int *p){
    int t;
    for(int i=0; i<BLK; i++){
        t=p[i];
    }
    return t;
}

int main(void){
//    int *p=(int*)malloc(BLK);
    int a[BLK];
    int *p = a;
    monfun(p);
    return 0;
}
