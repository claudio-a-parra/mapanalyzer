// compile  : gcc -Wall -g -Og
// run-args : 43 13
// prefix   : valgrind --tool=massif --time-unit=B

#include <stdlib.h>
void ggg(void){
    int* gp=(int*)malloc(4000);
    gp[0] = 0;
}

void fff(void){
    int* fp=(int*)malloc(2000);
    fp[0] = 0;
    ggg();
}

int main(void){
    int i;
    int* a[10];
    for (i = 0; i < 10; i++) {
        a[i] = malloc(1000);
    }
    int * x=(int*)malloc(1);
    fff();
    ggg();
    for (i = 0; i < 10; i++) {
        free(a[i]);
    }
    return 0;
}
